import bpy
from bpy.props import StringProperty, BoolProperty, FloatProperty, EnumProperty
from bpy.types import PropertyGroup

class PicoControllerProperties(PropertyGroup):
    """Propriedades do Addon BitControl armazenadas na cena."""
    
    com_port: StringProperty(
        name="Porta COM",
        description="Porta COM para conectar ao Pico W",
        default=""
    )
    
    is_connected: BoolProperty(
        name="Conectado",
        description="Status da conexão serial",
        default=False
    )
    
    control_mode: EnumProperty(
        name="Modo de Controle",
        items=[
            ('VIEWPORT', "Viewport", "Controlar a navegação da viewport"),
            ('OBJECT', "Objeto", "Controlar a rotação do objeto ativo"),
        ],
        default='VIEWPORT'
    )
    
    target_object: StringProperty(
        name="Objeto Alvo",
        description="Nome do objeto a ser controlado"
    )
    
    rotation_speed: FloatProperty(
        name="Sensibilidade Rotação",
        default=1.0,
        min=0.1,
        max=5.0
    )
    
    zoom_speed: FloatProperty(
        name="Velocidade de Zoom",
        default=1.0,
        min=0.1,
        max=5.0
    )

    smoothing_factor: FloatProperty(
        name="Suavização",
        description="Fator de suavização para o movimento do joystick",
        default=0.1,
        min=0.01,
        max=1.0
    )
    
    text_buffer: StringProperty(
        name="Buffer de Texto",
        description="Buffer para o teclado virtual",
        default=""
    )
    
    rename_target: EnumProperty(
        name="Alvo da Renomeação",
        items=[
            ('OBJECT', "Objeto", "Renomear o objeto ativo"),
            ('MATERIAL', "Material", "Renomear o material ativo"),
            ('COLLECTION', "Coleção", "Renomear a coleção ativa"),
            ('TEXTURE', "Textura", "Renomear a textura ativa"),
        ],
        default='OBJECT'
    )