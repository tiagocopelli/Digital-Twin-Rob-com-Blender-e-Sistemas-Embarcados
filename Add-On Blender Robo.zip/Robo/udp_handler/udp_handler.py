# Ficheiro: udp_handler/udp_handler.py

import bpy
import socket

# --- Configurações ---
PICO_IP = "192.168.137.21"  
PICO_PORT = 8888
PC_PORT = 8889  # <-- PORTA DIFERENTE para o Blender escutar!

# ✅ CORREÇÃO: Variáveis globais a nível de MÓDULO
robo_udp_socket = None
pico_ip = PICO_IP

def open_udp_socket():
    """Abre o socket UDP global para ENVIAR e RECEBER."""
    global robo_udp_socket
    
    if robo_udp_socket:
        print("Socket UDP já estava aberto.")
        return True
    
    try:
        # Cria socket UDP
        robo_udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        # IMPORTANTE: Faz bind em uma porta para receber respostas
        # Usa IP 0.0.0.0 para escutar em todas interfaces
        robo_udp_socket.bind(("0.0.0.0", PC_PORT))
        
        # Configura como não-bloqueante
        robo_udp_socket.setblocking(False)
        
        print(f"Socket UDP criado e bind na porta {PC_PORT}")
        print(f"Conectando ao Pico em {PICO_IP}:{PICO_PORT}")
        return True
        
    except Exception as e:
        print(f"Falha ao criar/bind socket UDP: {e}")
        robo_udp_socket = None
        return False

def close_udp_socket():
    """Fecha o socket UDP global."""
    global robo_udp_socket
    
    if robo_udp_socket:
        robo_udp_socket.close()
        robo_udp_socket = None
        print("Socket UDP fechado.")
        
def send_servo_data(s1, s2, s3, s4):
    """Envia os 4 ângulos dos servos via UDP."""
    global robo_udp_socket
    
    if not robo_udp_socket:
        return

    mensagem = f"S1:{int(s1)},S2:{int(s2)},S3:{int(s3)},S4:{int(s4)}"
    
    try:
        robo_udp_socket.sendto(mensagem.encode('utf-8'), (PICO_IP, PICO_PORT))
        print(f"Enviado UDP: {mensagem}")
    except Exception as e:
        print(f"Erro ao enviar UDP: {e}")

def send_esteira_state(ativa: bool):
    """Envia comando de ligar/desligar a esteira via UDP."""
    global robo_udp_socket

    if not robo_udp_socket:
        return

    estado = 1 if ativa else 0
    mensagem = f"ESTEIRA:{estado}"

    try:
        robo_udp_socket.sendto(mensagem.encode("utf-8"), (PICO_IP, PICO_PORT))
        print(f"Enviado UDP: {mensagem}")
    except Exception as e:
        print(f"Erro ao enviar estado da esteira: {e}")

# Nova função para receber dados
def receive_data():
    """Tenta receber dados do Pico (não bloqueante)."""
    global robo_udp_socket
    
    if not robo_udp_socket:
        return None
    
    try:
        # Tenta receber sem bloquear
        data, addr = robo_udp_socket.recvfrom(1024)
        return data.decode('utf-8').strip(), addr
    except socket.error:
        # Não há dados disponíveis
        return None
    except Exception as e:
        print(f"Erro ao receber dados: {e}")
        return None