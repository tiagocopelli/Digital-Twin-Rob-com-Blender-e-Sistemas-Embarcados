# Ficheiro: __init__.py

bl_info = {
    "name": "Robô Digital Twin (UDP)",
    "author": "Tiago Lauriano Copelli",
    "version": (2, 3),
    "blender": (3, 0, 0),
    "location": "3D Viewport > N Panel > Robô",
    "description": "Controla um robô virtual e um Pico W real via UDP (Com Heartbeat).",
    "category": "3D View",
}

import bpy
from math import radians

# Importa as classes dos nossos ficheiros locais
from .panel.panel_main import PainelRobo
from .operators.op_connect import ROBO_OT_OpenSocket, ROBO_OT_CloseSocket
from .udp_handler import udp_handler 

garra_ja_fechou = False
peca_em_aproximacao = None
DIST_CAPTURA = 0.15     
DIST_PARENT = 0.03      
VEL_APROX = 0.02        

updating_internal = False


# --- FUNÇÃO DE MAPEAMENTO ---
def map_range(value, from_min, from_max, to_min, to_max):
    """Converte um valor de uma faixa para outra"""
    value = max(min(value, from_max), from_min)
    return (value - from_min) * (to_max - to_min) / (from_max - from_min) + to_min

# --- [NOVO] FUNÇÃO HEARTBEAT (Mantém a conexão viva) ---
def heartbeat_timer():
    """
    Envia os dados atuais a cada 1 segundo para impedir
    que o Pico mostre 'OFFLINE' no display.
    """
    # 1. Obter objetos e valores atuais
    j1_obj = bpy.data.objects.get("Junta1")
    j2_obj = bpy.data.objects.get("Junta2")
    j3_obj = bpy.data.objects.get("Junta3")
    valor_garra = bpy.context.scene.garra_total

    ang_virtual_1 = getattr(j1_obj, "angulo", 0.0) if j1_obj else 0.0
    ang_virtual_2 = getattr(j2_obj, "Ang", 0.0) if j2_obj else 0.0
    ang_virtual_3 = getattr(j3_obj, "ang", 0.0) if j3_obj else 0.0

    # 2. Mapeamento (Igual ao callback central)
    ang_real_1 = map_range(ang_virtual_1, -90, 90, 0, 180)
    ang_real_2 = map_range(ang_virtual_2, -90, 90, 0, 180)
    ang_real_3 = map_range(ang_virtual_3, -90, 90, 0, 180)
    ang_real_4_garra = map_range(valor_garra, 0, 1, 0, 90) 

    # 3. Enviar para manter o Pico acordado
    udp_handler.send_servo_data(
        ang_real_1, 
        ang_real_2, 
        ang_real_3, 
        ang_real_4_garra
    )
    
    # Retorna 1.0 para executar novamente daqui a 1 segundo
    return 1.0 


# --- FUNÇÃO DE CALLBACK CENTRAL ---
def central_update_callback(self, context):
    """ Chamada quando movem os sliders """
    
    global updating_internal

    # 🚫 Se a mudança veio do Pico, NÃO reenvia
    if updating_internal:
        return None

    # --- 1. Atualizar o Robô Virtual ---
    valor_garra = context.scene.garra_total 
    
    garra_min, garra_max = 0.100, -0.400
    garra2_min, garra2_max = -5.0, 20.0
    garra_val = garra_min + (garra_max - garra_min) * valor_garra
    garra2_val = garra2_min + (garra2_max - garra2_min) * valor_garra

    garra1 = bpy.data.objects.get("Garra")
    garra2 = bpy.data.objects.get("Garra2")

    if garra1:
        garra1["garra"] = garra_val
        garra1.rotation_euler.z = radians(garra_val)
    if garra2:
        garra2["garra2"] = garra2_val
        garra2.rotation_euler.z = radians(garra2_val)

    # --- 2. Enviar Dados para o Robô Real ---
    j1_obj = bpy.data.objects.get("Junta1")
    j2_obj = bpy.data.objects.get("Junta2")
    j3_obj = bpy.data.objects.get("Junta3")

    ang_virtual_1 = getattr(j1_obj, "angulo", 0.0) if j1_obj else 0.0
    ang_virtual_2 = getattr(j2_obj, "Ang", 0.0) if j2_obj else 0.0
    ang_virtual_3 = getattr(j3_obj, "ang", 0.0) if j3_obj else 0.0
    
    ang_real_1 = map_range(ang_virtual_1, -90, 90, 0, 180)
    ang_real_2 = map_range(ang_virtual_2, -90, 90, 0, 180)
    ang_real_3 = map_range(ang_virtual_3, -90, 90, 0, 180)
    ang_real_4_garra = map_range(valor_garra, 0, 1, 0, 90) 
    
    udp_handler.send_servo_data(
        ang_real_1, 
        ang_real_2, 
        ang_real_3, 
        ang_real_4_garra
    )

    # --- Lógica de Pegar/Soltar ---
    global garra_ja_fechou
    garra_ref = bpy.data.objects.get("Garra")
    colecao = bpy.data.collections.get("Pecas")
    sensor = bpy.data.objects.get("SensorGarra")

    if garra_ref and colecao and sensor:
        peca_agarrada = None
        for obj in colecao.objects:
            if obj.parent == garra_ref:
                peca_agarrada = obj
                break

        if valor_garra <= 0.2 and not garra_ja_fechou and peca_agarrada is None:
            for obj in colecao.objects:
                if obj.parent is None:
                    if ponto_dentro_bbox(obj.matrix_world.translation, sensor):
                        if obj.rigid_body:
                            obj.rigid_body.enabled = False
                            obj.rigid_body.kinematic = True
                        context.view_layer.update()
                        obj.parent = garra_ref
                        obj.matrix_parent_inverse = garra_ref.matrix_world.inverted()
                        garra_ja_fechou = True
                        break

        elif valor_garra > 0.25 and peca_agarrada:
            mw = peca_agarrada.matrix_world.copy()
            peca_agarrada.parent = None
            peca_agarrada.matrix_parent_inverse.identity()
            peca_agarrada.matrix_world = mw
            if peca_agarrada.rigid_body:
                bpy.context.view_layer.objects.active = peca_agarrada
                bpy.ops.rigidbody.object_remove()
            bpy.context.view_layer.objects.active = peca_agarrada
            bpy.ops.rigidbody.object_add()
            rb = peca_agarrada.rigid_body
            rb.type = 'ACTIVE'
            rb.kinematic = False
            rb.mass = 1.0
            rb.friction = 0.6
            rb.restitution = 0.0
            context.view_layer.update()
            garra_ja_fechou = False

        elif valor_garra > 0.25 and peca_agarrada is None:
            garra_ja_fechou = False
    return None

def ponto_dentro_bbox(ponto, obj):
    local = obj.matrix_world.inverted() @ ponto
    return (abs(local.x) <= 0.5 and abs(local.y) <= 0.5 and abs(local.z) <= 0.5)

def esteira_anim_timer():
    scene = bpy.context.scene
    if not scene.esteira_ativa: return None
    esteira = bpy.data.objects.get("Esteira")
    if esteira: esteira.location.y += 0.02
    return 0.02

def esteira_update_callback(self, context):
    estado = context.scene.esteira_ativa
    udp_handler.send_esteira_state(estado)
    if estado: bpy.app.timers.register(esteira_anim_timer)

# --- ESCUTA O PICO (PICO -> BLENDER) ---
def receive_data_timer():
    """Escuta dados do Pico e atualiza o Blender."""
    global updating_internal
    
    result = udp_handler.receive_data()
    
    if result:
        msg, addr = result
        print(f"[DEBUG 1] ========== RECEBIDO ==========")
        print(f"[DEBUG 2] Mensagem bruta: '{msg}'")
        print(f"[DEBUG 3] Endereço: {addr}")
        
        if msg.startswith("FB:"):
            print(f"[DEBUG 4] É mensagem FB!")
            valores = msg[3:].split(',')
            print(f"[DEBUG 5] Valores divididos: {valores}")
            print(f"[DEBUG 6] Quantidade de valores: {len(valores)}")
            
            if len(valores) == 4:
                r1, r2, r3, r4 = map(int, valores)
                print(f"[DEBUG 7] Valores inteiros: r1={r1}, r2={r2}, r3={r3}, r4={r4}")
                
                # 🔥 CORREÇÃO: Converte Real → Virtual
                v1 = r1  # Ex: 90 → 0, 135 → 45, 45 → -45
                v2 = r2
                v3 = r3
                #v_garra = r4   # 0-90 → 0-1
                v_garra = 1.0 if r4 == 1 else 0.0
                
                print(f"[DEBUG 8] Valores convertidos: v1={v1}, v2={v2}, v3={v3}, v_garra={v_garra}")
                print(f"[DEBUG 9] Chamando update_sliders_from_pico...")
                
                # Chama a função que atualiza tudo
                update_sliders_from_pico(v1, v2, v3, v_garra)
                
                print(f"[DEBUG 10] update_sliders_from_pico COMPLETO")
            else:
                print(f"[DEBUG ERRO] Esperava 4 valores, recebeu {len(valores)}")
        else:
            print(f"[DEBUG AVISO] Mensagem não começa com FB: '{msg}'")
    
    return 0.05


def update_sliders_from_pico(v1, v2, v3, v_garra):
    global updating_internal
    updating_internal = True

    scene = bpy.context.scene

    j1 = bpy.data.objects.get("Junta1")
    j2 = bpy.data.objects.get("Junta2")
    j3 = bpy.data.objects.get("Junta3")

    if j1:
        j1.angulo = v1
        j1.rotation_euler.z = radians(v1)

    if j2:
        j2.Ang = v2
        j2.rotation_euler.z = radians(v2)

    if j3:
        j3.ang = v3
        j3.rotation_euler.z = radians(v3)

    scene.garra_total = v_garra

    updating_internal = False

    # Força redraw da UI
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()

# --- REGISTRO ---
classes = (
    PainelRobo,
    ROBO_OT_OpenSocket,
    ROBO_OT_CloseSocket
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Estas propriedades criam controles na interface
    bpy.types.Object.angulo = bpy.props.FloatProperty(
        name="Angulo Junta 1", 
        min=-90, max=90, 
        default=0,
        update=central_update_callback
    )
    
    bpy.types.Object.Ang = bpy.props.FloatProperty(
        name="Angulo Junta 2", 
        min=-90, max=90, 
        default=0,
        update=central_update_callback
    )
    
    bpy.types.Object.ang = bpy.props.FloatProperty(
        name="Angulo Junta 3", 
        min=-90, max=90, 
        default=0,
        update=central_update_callback
    )
    
    bpy.types.Scene.garra_total = bpy.props.FloatProperty(
        name="Abrir Garra", 
        min=0, max=1, 
        default=0,
        update=central_update_callback
    )
    
    # 🔥 ADICIONA A PROPRIEDADE DA ESTEIRA
    bpy.types.Scene.esteira_ativa = bpy.props.BoolProperty(
        name="Esteira Ativa",
        default=False,
        update=esteira_update_callback
    )
    
    # Abre o socket
    if udp_handler.open_udp_socket():
        udp_handler.send_servo_data(90, 90, 90, 0)
    
    # ✅ Inicia o Timer de Heartbeat
    if not bpy.app.timers.is_registered(heartbeat_timer):
        bpy.app.timers.register(heartbeat_timer)

    # ✅ Inicia o Timer de Recepção
    if not bpy.app.timers.is_registered(receive_data_timer):
        bpy.app.timers.register(receive_data_timer)
    
def unregister():
    # ✅ Para os Timers
    if bpy.app.timers.is_registered(heartbeat_timer):
        bpy.app.timers.unregister(heartbeat_timer)
    
    if bpy.app.timers.is_registered(receive_data_timer):
        bpy.app.timers.unregister(receive_data_timer)

    udp_handler.close_udp_socket()
    
    del bpy.types.Scene.esteira_ativa
    del bpy.types.Scene.garra_total
    del bpy.types.Object.angulo
    del bpy.types.Object.Ang
    del bpy.types.Object.ang
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()