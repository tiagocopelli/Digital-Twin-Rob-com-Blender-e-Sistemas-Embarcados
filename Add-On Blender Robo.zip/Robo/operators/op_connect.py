# Ficheiro: operators/op_connect.py

import bpy
# Importa as funções do nosso módulo de conexão
from ..udp_handler import udp_handler 

class ROBO_OT_OpenSocket(bpy.types.Operator):
    """Abre o socket UDP para comunicar com a Pico W."""
    bl_idname = "robo.open_socket"
    bl_label = "Conectar UDP"
    
    def execute(self, context):
        if udp_handler.open_udp_socket():
            self.report({'INFO'}, f"Socket UDP aberto para {udp_handler.PICO_IP}")
        else:
            self.report({'ERROR'}, "Falha ao abrir socket UDP.")
        return {'FINISHED'}

class ROBO_OT_CloseSocket(bpy.types.Operator):
    """Fecha o socket UDP."""
    bl_idname = "robo.close_socket"
    bl_label = "Desconectar UDP"
    
    def execute(self, context):
        udp_handler.close_udp_socket()
        self.report({'INFO'}, "Socket UDP fechado.")
        return {'FINISHED'}