import serial
import serial.tools.list_ports
import threading
import time

class SerialManager:
    """
    Gere a conexão serial com o dispositivo Pico W.
    """
    def __init__(self):
        self.ser = None
        self.read_thread = None
        self.stop_thread = False
        self.data_callback = None

    def get_ports(self):
        """Retorna uma lista de todas as portas COM disponíveis."""
        return [port.device for port in serial.tools.list_ports.comports()]

    def connect(self, port, baudrate=115200):
        """Tenta conectar-se à porta serial especificada."""
        try:
            self.disconnect() # Garante que qualquer conexão anterior seja fechada
            self.ser = serial.Serial(port, baudrate, timeout=0)
            self.stop_thread = False
            self.read_thread = threading.Thread(target=self._read_loop, daemon=True)
            self.read_thread.start()
            print(f"[BitControl] Conectado com sucesso a {port}")
            return True
        except serial.SerialException as e:
            print(f"[BitControl] Erro ao conectar: {e}")
            self.ser = None
            return False

    def disconnect(self):
        """Desconecta da porta serial."""
        self.stop_thread = True
        if self.read_thread and self.read_thread.is_alive():
            self.read_thread.join(timeout=1.0)
        
        if self.ser and self.ser.is_open:
            self.ser.close()
            print("[BitControl] Desconectado.")
        self.ser = None

    def _read_loop(self):
        """Loop executado na thread de leitura para ler dados da serial."""
        while not self.stop_thread and self.ser and self.ser.is_open:
            try:
                if self.ser.in_waiting > 0:
                    line = self.ser.readline().decode('utf-8').strip()
                    if line and self.data_callback:
                        # Chama a função de callback no __init__.py com o dado
                        bpy.app.timers.register(lambda l=line: self.data_callback(l))
            except Exception as e:
                print(f"[BitControl] Erro na thread de leitura: {e}")
                # Se houver um erro grave (ex: dispositivo desconectado), para o loop
                self.stop_thread = True
            time.sleep(0.01) # Pequena pausa para não sobrecarregar o CPU

    def set_data_callback(self, callback):
        """Define a função que será chamada quando novos dados chegarem."""
        self.data_callback = callback

    def send(self, message):
        """Envia uma mensagem de texto para o dispositivo serial."""
        if self.ser and self.ser.is_open:
            try:
                self.ser.write((message + '\n').encode('utf-8'))
            except Exception as e:
                print(f"[BitControl] Erro ao enviar dados: {e}")
        else:
            print("[BitControl] Erro: Serial não está conectada.")

# Cria uma instância única (singleton) para ser importada por outros ficheiros
serial_manager = SerialManager()