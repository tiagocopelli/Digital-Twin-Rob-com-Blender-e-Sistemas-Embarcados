# Ficheiro: __init__.py

bl_info = {
    "name": "Robô Digital Twin (UDP)",
    "author": "Tiago Lauriano Copelli",
    "version": (2, 1), # Versão atualizada
    "blender": (3, 0, 0),
    "location": "3D Viewport > N Panel > Robô",
    "description": "Controla um robô virtual e um Pico W real via UDP.",
    "category": "3D View",
}

import bpy
from math import radians

# Importa as classes dos nossos ficheiros locais
from .panel.panel_main import PainelRobo
from .operators.op_connect import ROBO_OT_OpenSocket, ROBO_OT_CloseSocket
from .udp_handler import udp_handler # Importa o módulo de conexão

garra_ja_fechou = False
peca_em_aproximacao = None
DIST_CAPTURA = 0.15     # distância para começar a puxar
DIST_PARENT = 0.03      # distância para colar na garra
VEL_APROX = 0.02        # velocidade do movimento


# --- FUNÇÃO DE MAPEAMENTO ---
def map_range(value, from_min, from_max, to_min, to_max):
    """Converte um valor de uma faixa para outra (ex: -90..90 para 0..180)"""
    # Garante que o valor não saia da faixa de entrada
    value = max(min(value, from_max), from_min)
    # Mapeia
    return (value - from_min) * (to_max - to_min) / (from_max - from_min) + to_min

# --- FUNÇÃO DE CALLBACK CENTRAL (O CÉREBRO) ---
def central_update_callback(self, context):
    """
    Esta função é chamada automaticamente sempre que QUALQUER slider é movido.
    Ela sincroniza o robô virtual e o real.
    """
    
    # --- 1. Atualizar o Robô Virtual (Lógica da Garra) ---
    
    valor_garra = context.scene.garra_total # Valor de 0 a 1
    
    # Mapeamento linear para cada garra (do seu código)
    garra_min, garra_max = 0.100, -0.400
    garra2_min, garra2_max = -5.0, 20.0
    garra_val = garra_min + (garra_max - garra_min) * valor_garra
    garra2_val = garra2_min + (garra2_max - garra2_min) * valor_garra

    garra1 = bpy.data.objects.get("Garra")
    garra2 = bpy.data.objects.get("Garra2")

    if garra1:
        garra1["garra"] = garra_val
        garra1.rotation_euler.z = radians(garra_val)
    if garra2:
        garra2["garra2"] = garra2_val
        garra2.rotation_euler.z = radians(garra2_val)

    # --- 2. Enviar Dados para o Robô Real (Pico W) via UDP ---
    
    # Obter os valores virtuais (ex: -90 a +90) dos sliders
    j1_obj = bpy.data.objects.get("Junta1")
    j2_obj = bpy.data.objects.get("Junta2")
    j3_obj = bpy.data.objects.get("Junta3")

    ang_virtual_1 = getattr(j1_obj, "angulo", 0.0) if j1_obj else 0.0
    ang_virtual_2 = getattr(j2_obj, "Ang", 0.0) if j2_obj else 0.0
    ang_virtual_3 = getattr(j3_obj, "ang", 0.0) if j3_obj else 0.0
    
    # ✅ --- MAPEAMENTO PARA OS SERVOS REAIS ---
    # Converte a faixa virtual (ex: -90 a +90) para a faixa física (0 a 180)
    # Quando o slider estiver em 0, o servo real irá para 90.
    ang_real_1 = map_range(ang_virtual_1, -90, 90, 0, 180)
    ang_real_2 = map_range(ang_virtual_2, -90, 90, 0, 180)
    ang_real_3 = map_range(ang_virtual_3, -90, 90, 0, 180)
    
    # Mapeia a garra (0 a 1) para um ângulo físico (ex: 0 a 90)
    ang_real_4_garra = map_range(valor_garra, 0, 1, 0, 90) 
    
    # Envia os 4 valores REAIS (0-180) para o módulo UDP
    udp_handler.send_servo_data(
        ang_real_1, 
        ang_real_2, 
        ang_real_3, 
        ang_real_4_garra
    )

    # --- PEGAR / SOLTAR PEÇAS (COM SENSOR EMPTY) ---
    global garra_ja_fechou

    garra_ref = bpy.data.objects.get("Garra")
    colecao = bpy.data.collections.get("Pecas")
    sensor = bpy.data.objects.get("SensorGarra")

    if garra_ref and colecao and sensor:

        # Procura peça já agarrada
        peca_agarrada = None
        for obj in colecao.objects:
            if obj.parent == garra_ref:
                peca_agarrada = obj
                break

        # ===== PEGAR (evento de fechar) =====
        if valor_garra <= 0.2 and not garra_ja_fechou and peca_agarrada is None:

            for obj in colecao.objects:
                # Só tenta pegar peças SEM parent
                if obj.parent is None:

                    if ponto_dentro_bbox(obj.matrix_world.translation, sensor):
                        
                        # Desliga a física ANTES de parentar
                        if obj.rigid_body:
                            obj.rigid_body.enabled = False
                            obj.rigid_body.kinematic = True
                        
                        # Atualiza a cena
                        context.view_layer.update()
                        
                        # Agora parenta
                        obj.parent = garra_ref
                        obj.matrix_parent_inverse = garra_ref.matrix_world.inverted()
                        
                        garra_ja_fechou = True
                        print(f"✅ Peça '{obj.name}' capturada!")
                        break

        # ===== SOLTAR (CORRETO E ESTÁVEL) =====
        elif valor_garra > 0.25 and peca_agarrada:

            print(f"🔓 Soltando '{peca_agarrada.name}'")

            # 1. Salva a transformação global
            mw = peca_agarrada.matrix_world.copy()

            # 2. Remove o parent
            peca_agarrada.parent = None
            peca_agarrada.matrix_parent_inverse.identity()

            # 3. Aplica a transformação global salva
            peca_agarrada.matrix_world = mw

            # 4. Remove o rigid body COMPLETAMENTE
            if peca_agarrada.rigid_body:
                bpy.context.view_layer.objects.active = peca_agarrada
                bpy.ops.rigidbody.object_remove()

            # 5. Recria o rigid body (zera o estado interno do Bullet)
            bpy.context.view_layer.objects.active = peca_agarrada
            bpy.ops.rigidbody.object_add()

            # 6. Configura para cair
            rb = peca_agarrada.rigid_body
            rb.type = 'ACTIVE'
            rb.kinematic = False
            rb.mass = 1.0
            rb.friction = 0.6
            rb.restitution = 0.0

            # 7. Atualiza a cena
            context.view_layer.update()

            print("✅ Peça solta corretamente — física reinicializada")

            garra_ja_fechou = False


        # ===== RESET da flag quando a garra abre (sem peça) =====
        elif valor_garra > 0.25 and peca_agarrada is None:
            garra_ja_fechou = False

    return None

def ponto_dentro_bbox(ponto, obj):
    # ponto em world space
    local = obj.matrix_world.inverted() @ ponto

    return (
        abs(local.x) <= 0.5 and
        abs(local.y) <= 0.5 and
        abs(local.z) <= 0.5
    )


def esteira_update_callback(self, context):
    """
    Callback chamado quando o checkbox da esteira é ligado/desligado
    """
    estado = context.scene.esteira_ativa
    udp_handler.send_esteira_state(estado)


def esteira_anim_timer():
    scene = bpy.context.scene

    if not scene.esteira_ativa:
        return None  # Para o timer

    esteira = bpy.data.objects.get("Esteira")
    if esteira:
        # MOVIMENTO LINEAR DA ESTEIRA (EIXO Y)
        esteira.location.y += 0.02

    return 0.02



def esteira_update_callback(self, context):
    estado = context.scene.esteira_ativa

    # Envia comando UDP
    udp_handler.send_esteira_state(estado)

    # Inicia animação se ligada
    if estado:
        bpy.app.timers.register(esteira_anim_timer)


# --- Lista de todas as classes para registo ---
classes = (
    PainelRobo,
    ROBO_OT_OpenSocket,
    ROBO_OT_CloseSocket
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # --- REGISTO DAS PROPRIEDADES (COM NOVOS LIMITES) ---
    # Agora os sliders vão de -90 a +90, com o padrão em 0.
    
    bpy.types.Object.angulo = bpy.props.FloatProperty(
        name="Angulo Junta 1", min=-90, max=90, default=0,
        update=central_update_callback
    )
    bpy.types.Object.Ang = bpy.props.FloatProperty(
        name="Angulo Junta 2", min=-90, max=90, default=0,
        update=central_update_callback
    )
    bpy.types.Object.ang = bpy.props.FloatProperty(
        name="Angulo Junta 3", min=-90, max=90, default=0,
        update=central_update_callback
    )

    # Regista a propriedade da garra na Cena
    bpy.types.Scene.garra_total = bpy.props.FloatProperty(
        name="Abrir Garra",
        description="Abre e fecha as duas garras",
        min=0, max=1, default=0,
        update=central_update_callback
    )

    bpy.types.Scene.esteira_ativa = bpy.props.BoolProperty(
        name="Esteira Ligada",
        description="Liga/desliga a esteira do robô",
        default=False,
        update=esteira_update_callback
    )
    
    # Abre o socket UDP automaticamente ao ativar o addon
    if udp_handler.open_udp_socket():
        # ✅ ENVIA O COMANDO DE "POSIÇÃO INICIAL" (Tudo 90)
        # O robô físico irá para 90° assim que o addon for ativado.
        # Os sliders no Blender estarão em 0°, que (pelo mapeamento) também
        # corresponde a 90°, mantendo tudo sincronizado.
        udp_handler.send_servo_data(90, 90, 90, 0) # (Garra em 0)

def unregister():
    udp_handler.close_udp_socket()
    
    del bpy.types.Scene.esteira_ativa
    del bpy.types.Scene.garra_total
    del bpy.types.Object.angulo
    del bpy.types.Object.Ang
    del bpy.types.Object.ang
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()