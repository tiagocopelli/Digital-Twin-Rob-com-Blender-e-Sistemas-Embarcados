# Ficheiro: panel/panel_main.py (Corrigido)

import bpy
from math import radians

class PainelRobo(bpy.types.Panel):
    """Cria o painel na 3D Viewport UI (N-Panel)"""
    bl_label = "Controle do Robô"
    bl_idname = "VIEW3D_PT_robo"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Robô' # Nome da aba no N-Panel

    def draw(self, context):
        layout = self.layout
        scene = context.scene # Acede à cena

        # --- Botões de Conexão UDP ---
        # Importa o estado do socket do módulo udp_handler
        from ..udp_handler import udp_handler 
        
        box = layout.box()
        box.label(text="Conexão UDP (Pico W)")
        
        # Verifica o socket diretamente do módulo importado
        if not udp_handler.robo_udp_socket:
            box.operator("robo.open_socket", text="Conectar", icon='PLAY')
        else:
            ip = udp_handler.pico_ip
            box.label(text=f"Conectado a: {ip}")
            box.operator("robo.close_socket", text="Desconectar", icon='PAUSE')
        
        layout.separator()
        box = layout.box()
        box.label(text="Controles dos Servos")

        # --- Sliders das Juntas ---
        # Acede diretamente às propriedades personalizadas dos objetos
        
        # Junta1
        obj = bpy.data.objects.get("Junta1")
        if obj:
            # Acede à propriedade "angulo" do objeto
            layout.prop(obj, "angulo", slider=True)
        else:
            layout.label(text="Objeto 'Junta1' não encontrado")

        # Junta2
        obj = bpy.data.objects.get("Junta2")
        if obj:
            # Acede à propriedade "Ang" do objeto
            layout.prop(obj, "Ang", slider=True)
        else:
            layout.label(text="Objeto 'Junta2' não encontrado")

        # Junta3
        obj = bpy.data.objects.get("Junta3")
        if obj:
            # Acede à propriedade "ang" do objeto
            layout.prop(obj, "ang", slider=True)
        else:
            layout.label(text="Objeto 'Junta3' não encontrado")

        # --- Slider da Garra ---
        # Acede à propriedade "garra_total" que está na Cena
        layout.prop(scene, "garra_total", slider=True)

        layout.separator()
        #box = layout.box()
        #box.label(text="Esteira")
        #box.prop(scene, "esteira_ativa", text="Ligar Esteira")
        